
//--------------------------------
// Lab 4 - Sample - Lab04_sample.c
//--------------------------------
//
//

#include "init.h"

void configureADC();
void InitGPIO();
void configureDAC();

ADC_HandleTypeDef hadc1;
HAL_StatusTypeDef adcSta;
GPIO_InitTypeDef GPIO_InitStruct;
DAC_HandleTypeDef DACHandler;
float result[16];
float aveV;
float maxV;
float minV;


// Main Execution Loop
int main(void)
{

	//Initialize the system
	int i = 0;
	float tmp = 0;
	int convResult = 0;
	Sys_Init();
	configureADC();
	configureDAC();
	HAL_DAC_Start(&DACHandler, DAC_CHANNEL_1);

	// Code goes here
	printf("\033[2J\033[;H");
	printf("start\r\n");
	fflush(stdout);
	while(1){
		if (i < 17){i = i + 1;}
		adcSta = HAL_ERROR;
		HAL_ADC_Start(&hadc1);
		while(adcSta != HAL_OK){	// Keep request uptil the reading is ready
			adcSta = HAL_ADC_PollForConversion(&hadc1, 10);
		}
		convResult = HAL_ADC_GetValue(&hadc1);	// Read ADC value
		// Set the DAC value
		HAL_DAC_SetValue(&DACHandler, DAC_CHANNEL_1, DAC_ALIGN_12B_R, convResult);
	}
}

void configureADC()
{
	ADC_ChannelConfTypeDef sConfig;
	// Enable the ADC Clock.
	__HAL_RCC_ADC1_CLK_ENABLE();

	hadc1.Instance = ADC1;
	hadc1.Init.ClockPrescaler = ADC_CLOCK_SYNC_PCLK_DIV6;
	hadc1.Init.Resolution = ADC_RESOLUTION_12B;
	hadc1.Init.ScanConvMode = DISABLE;
	hadc1.Init.ContinuousConvMode = DISABLE;
	hadc1.Init.DiscontinuousConvMode = DISABLE;
	hadc1.Init.DataAlign = ADC_DATAALIGN_RIGHT;
	hadc1.Init.NbrOfConversion = 1;
	hadc1.Init.DMAContinuousRequests = DISABLE;
	hadc1.Init.EOCSelection = ADC_EOC_SEQ_CONV;

	HAL_ADC_Init(&hadc1); // Initialize the ADC

	/* Available sampling times:

		ADC_SAMPLETIME_3CYCLES
	  ADC_SAMPLETIME_15CYCLES
		ADC_SAMPLETIME_28CYCLES
		ADC_SAMPLETIME_56CYCLES
		ADC_SAMPLETIME_84CYCLES
		ADC_SAMPLETIME_112CYCLES
		ADC_SAMPLETIME_144CYCLES
		ADC_SAMPLETIME_480CYCLES

	*/

	sConfig.Channel = ADC_CHANNEL_6;
	sConfig.Rank = 1;
	sConfig.SamplingTime = ADC_SAMPLETIME_15CYCLES;

	// Configure the ADC channel

	HAL_ADC_ConfigChannel(&hadc1,&sConfig);
}


void HAL_ADC_MspInit(ADC_HandleTypeDef *hadc)
{

	__HAL_RCC_GPIOA_CLK_ENABLE();
	// GPIO A6 Pin A0 for ADC
	GPIO_InitStruct.Pin = GPIO_PIN_6;
	GPIO_InitStruct.Mode = GPIO_MODE_ANALOG;	// Rising trigger
	GPIO_InitStruct.Pull = GPIO_PULLDOWN;	// Internal resistor pulldown
	HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);
	// GPIO A4 Pin A1 for DAC 
	GPIO_InitTypeDef GPIOinit;
	GPIOinit.Pin = GPIO_PIN_4;			//Pin4 of GPIOA
	GPIOinit.Mode = GPIO_MODE_ANALOG;	//Set Analog mode
	GPIOinit.Pull = GPIO_NOPULL;		//No pull up

	HAL_GPIO_Init(GPIOA,&GPIOinit);//Initialize GPIOA Pin4 as configured above

}

void configureDAC()
{

	// Enable the DAC Clock.
		__HAL_RCC_DAC_CLK_ENABLE();

	// Declare DAC_CahnnelConfTypeDef
	DAC_ChannelConfTypeDef ChannelConfig;

	//DAC channel OUT1 config
	ChannelConfig.DAC_Trigger = DAC_TRIGGER_NONE;
	ChannelConfig.DAC_OutputBuffer = DAC_OUTPUTBUFFER_ENABLE;

	//Set up DACHandler
	DACHandler.Instance = DAC;
	HAL_DAC_Init(&DACHandler); // Initialize the DAC

	// Configure the ADC channel
	HAL_DAC_ConfigChannel(&DACHandler, &ChannelConfig, DAC_CHANNEL_1);
}

