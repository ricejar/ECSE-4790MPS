/*
 * task3.c
 *
 *  Created on: Oct 23, 2021
 *      Author: wangy62
 */

#include "init.h"




int main(void){

	Sys_Init();
	uint32_t result;
	int32_t int1 = 1145;
	int32_t int2 = 1919;
	int32_t int3  = 0;
	int32_t i2 = 2;
	int32_t i3 = 3;
	int32_t i5 = 5;
	int32_t temp = 0;
	int32_t x = 539;
	int32_t y = 0;
	int32_t z = 0;
	unsigned char c;

	printf("\033[2J\033[;H");
	printf("start\r\n");
	fflush(stdout);
	//1, Add 2 hard code number
	asm("LDR r1, =0x00005D8A");
	asm("LDR r2, =0x0001B742");
	asm("ADD r3, r1 , r2");
	asm("STR r3,%0" : "=m" (result));

	printf("Result hex: %ld, dec: %lx \r\n",result,result);

	//2. multiply two int32_t value from c variable
	asm("MUL %[dest],%[tmp1],%[tmp2]" : [dest] "=r" (int3) : [tmp1] "r" (int1), [tmp2] "r" (int2));
	printf("Result hex: %ld, dec: %lx \r\n",int3,int3);

	//3. Equation 2/3*x+5 by assembly extension
	asm volatile ("MUL %[dest],%[tmp1],%[tmp2]" : [dest] "=r" (y) : [tmp1] "r" (i2), [tmp2] "r" (x));
	asm volatile ("SDIV %[dest],%[tmp1],%[tmp2]" :[dest] "=r" (z) : [tmp1] "r" (y), [tmp2] "r" (i3));
	asm volatile ("ADD %[dest],%[tmp1],%[tmp2]" : [dest] "=r" (y): [tmp1] "r" (i5), [tmp2] "r" (z));
	printf("Result hex: %ld, dec: %lx \r\n",y,y);

	//4. MAC command (2x+15)/3
	x = 539;
	asm("LDR r8 , =0x0000000F");
	asm("LDR r9 , =0x00000002");
	asm("LDR r7 , =0x00000003");
	asm volatile("MLA %[dest], %[tmp1], r9, r8" : [dest] "=r" (int3) : [tmp1] "r" (x));
	asm volatile("SDIV %[dest], %[tmp1], r7" : [dest] "=r" (temp) : [tmp1] "r" (int3) );
	printf("Result hex: %ld, dec: %lx \r\n",temp,temp);


	while(1){
		c = getchar();
	}


}
