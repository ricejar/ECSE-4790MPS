/*
 * task3.c
 *
 *  Created on: Oct 25, 2021
 *      Author: 18238
 */


#include "init.h"

int main(void)
{
	Sys_Init();
	uint32_t result;
	printf("\033[2J\033[;H");
	printf("Start\r\n");
	fflush(stdout);
	//1. Add 2 hard code number
	asm("LDR r1, =0x0000abcd");
	asm("LDR r2, =0x0000dcba");
	asm("ADD r3, r1, r2");
	asm("STR r3, %0" : "=m" (result));
	printf("Hex: %lx, Dec: %ld \r\n",result,result);

	//2.  multiply 2 single precision floats
	float num1 = 12.3;
	float num2 = 32.1;
	float num3 = 1;
	asm("VMUL.F32 %[dest], %[tmp1], %[tmp2]" : [dest] "=w" (num3) : [tmp1] "w" (num1) , [tmp2] "w" (num2));
	printf("Dec: %f \r\n", num3);

	//3. Equation 2/3*x+5 by assembly extension through float point action
	float a = 6;
	float b = 2;
	float c = 3;
	float g = 5;
	float d = 0;
	float e = 0;
	float f = 0;
	asm volatile ("VMUL.F32 %[dest], %[tmp1], %[tmp2]" : [dest] "=w" (d) : [tmp1] "w" (a), [tmp2] "w" (b));
	asm volatile ("VDIV.F32 %[dest], %[tmp1], %[tmp2]" : [dest] "=w" (e) : [tmp1] "w" (d), [tmp2] "w" (c));
	asm volatile ("VADD.F32 %[dest], %[tmp1], %[tmp2]" : [dest] "=w" (f) : [tmp1] "w" (e), [tmp2] "w" (g));
	printf("Dec: %f \r\n",f);

	//4 MAC command
	float x = 2;
	float y = 0;
	asm volatile ("VMLA.F32 %[dest], %[tmp1], %[tmp2]" : [dest] "=w" (y) : [tmp1] "w" (x), [tmp2] "w" (b));
	printf("Dec: %f \r\n",y);

}
